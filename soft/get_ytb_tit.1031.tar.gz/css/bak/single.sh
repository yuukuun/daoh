
#!/bin/bash
##################################################################################################
#youtube-dl --get-id --proxy socks5://127.0.0.1:1080 https://www.youtube.com/channel/UC8UCbiPrm2zN9nZHKdTevZA > temp.txt
##################################################################################################

ht='<div id="a@n" onclick="play(https://www.youtube.com/embed/@p?autoplay=1)" class="col-xs-12 col-md-6 store"><a href="#a@n" ><p class="lead text-left storetype">@t</p></a></div>'
sed -i "/\"row ins\"/a\ \<span id=\"ss\"\>\<\/span\>" ./index.html


for id in $(cat *.db)
do

###下载控制,默认不下载到本地
# num=0
# num=$(youtube-dl -F --proxy socks5://127.0.0.1:1080 $id | grep 'audio only' | head -n 1 | awk '{print $1}')
# youtube-dl -f $num -o "%(upload_date)s.%(id)s.%(ext)s" --proxy socks5://127.0.0.1:1080 $id
###标题
title=$(/usr/local/bin/youtube-dl -e $id )	#获取标题
# yer=$(/usr/local/bin/youtube-dl -e  $id | cut -f 3 -d '/')	#获取标题中时间
j=$(date +%s)


###排序最新在前面i\.如果最旧在前面a\
sed -i "/\"ss\"/i\ $ht" ./index.html

sed -i "s%@t%$title%g" ./index.html
sed -i "s/@n/$j/g" ./index.html

###插入id
sed -i "s/@p/$id/g" ./index.html

### 获取,添加年份	#yer=$(($yer+1))

# sed -i "s/@y/$yer/g" ./index.html

##显示
cat index.html

done
### play()内容添加单引号
sed -i "s/play(http/play(\'http/g" ./index.html
sed -i "s/play=1)/play=1\')/g" ./index.html

############################################################################################################
### 删除<span id="ss">
sed -i '/\"ss\"/d' ./index.html
