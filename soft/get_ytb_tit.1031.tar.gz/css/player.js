function play(urls) {
      var ifra = document.getElementById("player")  //获取ID为player 的iframe
      ifra.src = urls;                //修改iframe src
      ifra.style.display = "block"; //修改iframe css属性display
      document.getElementById("dow").style.display = "block";	//修改ID为downa <div>标签的css display属性
      document.getElementById("dowvi").setAttribute("href","../video.php?ids=" + urls);    //修改ID为downa <a>标签的href
      document.getElementById("dowviau").setAttribute("href","../audio.php?ids=" + urls);    //修改ID为downa <a>标签的href
      
  
}

