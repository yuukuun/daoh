#!/bin/bash
#安装
# sudo yum install -y wget psmisc
# sudo wget https://yt-dl.org/downloads/latest/youtube-dl -O /usr/local/bin/youtube-dl
# sudo chmod a+rx /usr/local/bin/youtube-dl

#变量;b

#proxy="--proxy socks5://127.0.0.1:1080"	#代理
rd="/usr/local/nginx/ytb/"	#网站根
btn='<div class="col-xs-6 col-md-2"><a href=".\/$cha\/index.html" target="_blank" class="btn btn-default btn-lg" role="button"><\/a><\/div>'
cd $rd
chan=$(grep "^arr" ./auto.sh | cut -f 1 -d '=') #获取数据名字
# cha=""
# url=""
#频道数组
arrwj=("王剑财经观察" "https://www.youtube.com/channel/UC8UCbiPrm2zN9nZHKdTevZA")
arra=("财经冷眼" "https://www.youtube.com/channel/UCn9_KbNANeyYREePe8YA2DA")
arrlyq=("無色覺醒" "https://www.youtube.com/channel/UCuCELS5-48uP1plTxlOJZQQ")
arrqj=("财经全世界" "https://www.youtube.com/channel/UCP_NCfAlWKZ7Km0VKuOysFQ")
arrrd=("热点互动" "https://www.youtube.com/channel/UCDrj0cP9ZQ7R9Qq_kZPpjKA")
arre=("年代向錢看" "https://www.youtube.com/channel/UCBuHkb1AS_yRQ71meFNQ3VQ")
arrlkf=("林宽风" "https://www.youtube.com/channel/UC5IawQpyAwdJ5mWzQNuSCDA")
arrhd=("亚洲红点传媒" "https://www.youtube.com/channel/UCZ051nuBdmdaYAXOl3btIPw")
arrb=("般若易理" "https://www.youtube.com/channel/UCJFFYu2Ry3ME7UEvVqvBp1g")
arrc=("正透視中國" "https://www.youtube.com/channel/UCGekZ_Ig4dP3NDcJCdOK6aA")
arrmjz=("明居正" "https://www.youtube.com/watch?list=PLtXdtmJEHwiwwn9JlFyrKObyoyMQHQ6XI")
arrd=("公子時評" "https://www.youtube.com/channel/UCrGSFNEBmCN0rqhATZels2Q")
arrf=("寰宇全視界" "https://www.youtube.com/channel/UCiOR3zQCU-tLza5g1MuqABA")





#################################函数定义必须写在前面#####################################
function getytb {	#添加

cd $rd$cha
sed -i "/\"row ins\"/a\ \<span id=\"ss\"\>\<\/span\>" ./index.html
	for id in $(cat $cha.db); do
		cd $rd$cha
		###标题
		title=$(/usr/local/bin/youtube-dl -e $proxy $id)
		#title=$(echo $alltitle | tr -d "[0-9]")	#获取标题
		# yer=$(echo $alltitle | tr -cd "[0-9]")	#获取标题中时间
		j=$(date +%s)
		###排序最新在前面i\.如果最旧在前面a\
		sed -i "/\"ss\"/i\ $ht" ./index.html

		sed -i "s%@t% $title%g" ./index.html
		sed -i "s/@n/$j/g" ./index.html

		###插入id
		sed -i "s/@p/$id/g" ./index.html

		### 获取,添加年份	#yer=$(($yer+1))

		# sed -i "s/@y/$yer/g" ./index.html
		### echo $i
	done
	sed -i "s/play(http/play(\'http/g" ./index.html
	sed -i "s/play=1)/play=1\')/g" ./index.html
	sed -i '/\"ss\"/d' ./index.html
	sed -i '/@y/d' ./index.html
}

function create {	#创建函数
	cd $rd
	mkdir $cha
	cp sub.html $cha'/index.html'
sed -i "/ins/i \<div class=\"col-xs-6 col-md-2\"><a href=\".\/$cha\/index.html\" target=\"_blank\" class=\"btn btn-default btn-lg\" role=\"button\">$cha<\/a><\/div>" index.html
	echo "sed -i \"s/$cha/\${$cha[0]}/2\" index.html">>temp.sh
	echo "sed -i \"s/#name#/\${$cha[0]}/g\" $cha/index.html">>temp.sh
	echo "sed -i \"s%#url#%\${$cha[1]}%g\" $cha/index.html">>temp.sh

	/bin/bash temp.sh >/dev/null
	url=$(cat ./auto.sh | grep "^arr" | grep $cha | cut -f 4 -d '"')	#获取下载地址
/usr/local/bin/youtube-dl --get-id $proxy $url > $rd$cha/$cha.db
cd $rd$cha
getytb
}

function addytb {	#添加函数
rm -rf $rd$cha/*.db
url=$(cat ./auto.sh | grep "^arr" | grep $cha | cut -f 4 -d '"')	#获取下载地址
/usr/local/bin/youtube-dl --get-id $proxy $url > $rd/temp.db &
# echo $url 
	sleep 40
	old=$(cat $rd$cha/index.html | grep "<div id" | cut -d '?' -f 1 | cut -d '/' -f 5 | head -1)
	for id in $(cat $rd/temp.db)
		do
			if [ "$id" = "$old" ]
			then
				/usr/bin/killall youtube-dl
				break	
			fi
		echo "$id" >>$rd$cha/$cha.db
		done
rm -rf $rd/temp.db
}


ht='<div id="a@n" onclick="play(https://www.youtube.com/embed/@p?autoplay=1)" class="col-xs-12 col-md-6 store"><a title="@t" href="#a@n" ><p class="lead text-left storetype">@t</p></a></div>'
dir=$(ls -F | grep "/" | cut -f1 -d '/' | grep "arr")



#################################主要运行内#######################################
cd $rd
echo '#!/bin/bash' >temp.sh
echo "cd $rd" >>temp.sh
grep "^arr" ./auto.sh >>temp.sh

for cha in $chan; do
cd $rd
	if [[ ! -d $rd$cha ]]; then	#if 判断目录是否存在
		# echo "$cha不存在 函数create()"

create




else	#存在的花判断
# echo "$cha存在"

# sed -i '/^arr/d' temp.sh
# grep "^arr" ./auto.sh >>temp.sh

addytb
getytb
	fi
done

# cd $rd
# rm -rf auto.sh
