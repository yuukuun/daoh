#!/bin/bash
#安装
# sudo yum install -y wget psmisc
# sudo wget https://yt-dl.org/downloads/latest/youtube-dl -O /usr/local/bin/youtube-dl
# sudo chmod a+rx /usr/local/bin/youtube-dl

rd="/usr/local/nginx/ytb/audwj/"	#修改1.网站根
cd $rd
# proxy="--proxy socks5://127.0.0.1:1080"	修改2.代理

url="https://www.youtube.com/channel/UC8UCbiPrm2zN9nZHKdTevZA"	#修改3.
ht='<div id="a@n" onclick="play(@p)" class="col-xs-12 col-md-6 store"><a title="@t" href="#a@n" ><p class="lead text-left storetype">@y @t</p></a></div>'


#更新开启
rm -rf "$rd"*.db
/usr/local/bin/youtube-dl --get-id $proxy $url >"$rd"temp.db &
sleep 30

#比较数据库
old=$(cat "$rd"index.html | grep "<div id" | cut -d '.' -f3 | sed -n '2p')	#修改4.获取html ID
for id in $(cat "$rd"temp.db)
	do
			if [ "$id" = "$old" ]
			then
				/usr/bin/killall youtube-dl
				break	
			fi
		echo "$id" >>"$rd"wj.db
	done



sed -i "/\"rows ins\"/a\ \<span id=\"ss\"\>\<\/span\>" "$rd"index.html
	for id in $(cat "$rd"wj.db); do
		# cd $rd$cha
		###标题
		alltitle=$(/usr/local/bin/youtube-dl -e $proxy $id)	#获取标题
		title=$(echo $alltitle | cut -d '/' -f1)	#修改5. 获取标题 
		date=$(echo $alltitle | tr -cd "[0-9]")	#修改6.获取标题中时间
		j=$(date +%s)
		###排序最新在前面i\.如果最旧在前面a\
		sed -i "/\"ss\"/i\ $ht" "$rd"index.html

		sed -i "s%@t%$title%g" "$rd"index.html
		sed -i "s/@n/$j/g" "$rd"index.html

		###插入id
		num=0
		num=$(/usr/local/bin/youtube-dl -F $proxy $id | grep '^[0-9]' | head -n 1 | awk '{print $1}')
		/usr/local/bin/youtube-dl -f $num -o "%(upload_date)s.%(id)s.%(ext)s" $proxy $id
		ids=$(ls | grep $id)	#用id来匹配文件
		sed -i "s/@p/$ids/g" "$rd"index.html

		### 获取,添加年份	#yer=$(($yer+1))

		sed -i "s/@y/$date/g" "$rd"index.html
		### echo $i
	done
sed -i "s/play(2/play(\'2/g" "$rd"index.html
sed -i "s/webm)/webm\')/g" "$rd"index.html
sed -i "s/m4a)/m4a\')/g" "$rd"index.html

sed -i "s%'20%'./audwj/20%g" index.html	# 修改7. 播放路径
sed -i '/\"ss\"/d' "$rd"index.html
