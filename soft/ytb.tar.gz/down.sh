#!/bin/bash
#安装
# sudo yum install -y wget psmisc
# sudo wget https://yt-dl.org/downloads/latest/youtube-dl -O /usr/local/bin/youtube-dl
# sudo chmod a+rx /usr/local/bin/youtube-dl

#proxy="--proxy socks5://127.0.0.1:1080"	#代理
rd="/usr/local/nginx/ytb/"	#网站根
btn='<div class="col-xs-6 col-md-2"><a href=".\/$cha\/index.html" target="_blank" class="btn btn-default btn-lg" role="button"><\/a><\/div>'
cd $rd
chan=$(grep "^dow" ./down.sh | cut -f 1 -d '=') #获取数据名字

#频道数组
dowwj=("音频" "https://www.youtube.com/playlist?list=PLjt2H8G1Z7ycZUkd1Zs9eM5I6rDWuajOp")


#################################函数定义必须写在前面#####################################
function getytb {	#添加

cd $rd$cha
sed -i "/\"row ins\"/a\ \<span id=\"ss\"\>\<\/span\>" ./index.html
	for id in $(cat $cha.db); do
		cd $rd$cha
		###标题
		alltitle=$(/usr/local/bin/youtube-dl -e $proxy $id)
		title=$(echo $alltitle | tr -d "[0-9]")	#获取标题
		yer=$(echo $alltitle | tr -cd "[0-9]")	#获取标题中时间
		j=$(date +%s)
		###排序最新在前面i\.如果最旧在前面a\
		sed -i "/\"ss\"/i\ $ht" ./index.html

		sed -i "s%@t% $title%g" ./index.html
		sed -i "s/@n/$j/g" ./index.html

		###插入id
		num=0
		num=$(/usr/local/bin/youtube-dl -F $proxy $id | grep '^[0-9]' | head -n 1 | awk '{print $1}')
		/usr/local/bin/youtube-dl -f $num -o "%(upload_date)s.%(id)s.%(ext)s" $proxy $id
		ids=$(ls | grep '^20' | tail -n 1)
		sed -i "s/@p/$ids/g" ./index.html

		### 获取,添加年份	#yer=$(($yer+1))

		sed -i "s/@y/$yer/g" ./index.html
		### echo $i
	done
	sed -i "s/play(2/play(\'2/g" ./index.html
	sed -i "s/webm)/webm\')/g" ./index.html
	sed -i "s/m4a)/m4a\')/g" ./index.html
	sed -i '/\"ss\"/d' ./index.html
	sed -i '/@y/d' ./index.html
}

function create {	#创建函数
	cd $rd
	mkdir $cha
	cp audio.html $cha'/index.html'
sed -i "/ins/i \<div class=\"col-xs-6 col-md-2\"><a href=\".\/$cha\/index.html\" target=\"_blank\" class=\"btn btn-default btn-lg\" role=\"button\">$cha<\/a><\/div>" index.html
	echo "sed -i \"s/$cha/\${$cha[0]}/2\" index.html">>temp.sh
	echo "sed -i \"s/#name#/\${$cha[0]}/g\" $cha/index.html">>temp.sh
	echo "sed -i \"s%#url#%\${$cha[1]}%g\" $cha/index.html">>temp.sh

	/bin/bash temp.sh >/dev/null
	url=$(cat ./down.sh | grep "^dow" | grep $cha | cut -f 4 -d '"')	#获取下载地址
/usr/local/bin/youtube-dl --get-id $proxy $url > $rd$cha/$cha.db
cd $rd$cha
getytb
}

function addytb {	#添加函数
rm -rf $rd$cha/*.db
url=$(cat ./down.sh | grep "^dow" | grep $cha | cut -f 4 -d '"')	#获取下载地址
/usr/local/bin/youtube-dl --get-id $proxy $url > $rd/temp.db &
# echo $url 
	sleep 40
	old=$(cat $rd$cha/index.html | grep "<div id" | grep "<div id" | cut -d '.' -f2)
	for id in $(cat $rd/temp.db)
		do
			if [ "$id" = "$old" ]
			then
				/usr/bin/killall youtube-dl
				break	
			fi
		echo "$id" >>$rd$cha/$cha.db
		done
rm -rf $rd/temp.db
}


ht='<div id="a@n" onclick="play(@p)" class="col-xs-12 col-md-6 store"><a title="@t" href="#a@n" ><p class="lead text-left storetype">@y @t</p></a></div>'
dir=$(ls -F | grep "/" | cut -f1 -d '/' | grep "arr")



#################################主要运行内#######################################
cd $rd
echo '#!/bin/bash' >temp.sh
echo "cd $rd" >>temp.sh
grep "^dow" ./down.sh >>temp.sh

for cha in $chan; do
cd $rd
	if [[ ! -d $rd$cha ]]; then	#if 判断目录是否存在
		# echo "$cha不存在 函数create()"

create

else	

addytb
getytb
	fi
done

