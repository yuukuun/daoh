#!/bin/bash
#安装
#sudo yum install -y wget psmisc vim && sudo wget https://yt-dl.org/downloads/latest/youtube-dl -O /usr/local/bin/youtube-dl && sudo chmod a+rx /usr/local/bin/youtube-dl
# sudo yum install -y wget psmisc vim 
# sudo wget https://yt-dl.org/downloads/latest/youtube-dl -O /usr/local/bin/youtube-dl
# sudo chmod a+rx /usr/local/bin/youtube-dl

rd="$(pwd)/"	#网站根

# proxy="--proxy socks5://127.0.0.1:1080"	#代理
# rd="/mnt/5/www/ytb/audlyq/"	#网站根

url="https://www.youtube.com/channel/UCuCELS5-48uP1plTxlOJZQQ"
ht='<div id="a@n" onclick="play(@p)" class="col-xs-12 col-md-6 store"><a title="@t" href="#a@n" ><p class="lead text-left storetype">@y @t</p></a></div>'


# #比较数据库
# rm -rf "$rd"*.db
# old=$(cat "$rd"index.html | grep "<div id" | cut -d '.' -f3 | sed -n '1p')	#获取html
# sleep 30
# #比较数据库
# old=$(cat "$rd"index.html | grep "<div id" | cut -d '.' -f2)
# for id in $(cat "$rd"temp.db)
# 	do
# 			if [ "$id" = "$old" ]
# 			then
# 				/usr/bin/killall youtube-dl
# 				break	
# 			fi
# 		echo "$id" >>"$rd"lyq.db
# 	done


sed -i "/\"row ins\"/a\ \<span id=\"ss\"\>\<\/span\>" "$rd"index.html
	for id in $(cat "$rd"lyq.db); do
		# cd $rd$cha
		###标题
		alltitle=$(/usr/local/bin/youtube-dl -e $proxy $id)	#获取标题
		title=$(echo $alltitle | cut -d '》' -f2 | cut -d '｜' -f1,2)	#获取标题
		date=$(echo $alltitle | tr -cd "[0-9]")	#获取标题中时间
		j=$(date +%s)
		###排序最新在前面i\.如果最旧在前面a\
		sed -i "/\"ss\"/i\ $ht" "$rd"index.html

		sed -i "s%@t%$title%g" "$rd"index.html
		sed -i "s/@n/$j/g" "$rd"index.html

		###插入id
		num=0
		num=$(/usr/local/bin/youtube-dl -F $proxy $id | grep '^[0-9]' | head -n 1 | awk '{print $1}')
		/usr/local/bin/youtube-dl -f $num -o "%(upload_date)s.%(id)s.%(ext)s" $proxy $id
		ids=$(ls | grep $id)	#用id来匹配文件者tail
		sed -i "s/@p/$ids/g" "$rd"index.html

		### 获取,添加年份	#yer=$(($yer+1))

		sed -i "s/@y/$date/g" "$rd"index.html
		### echo $i
	done
sed -i "s/play(2/play(\'2/g" "$rd"index.html
sed -i "s/webm)/webm\')/g" "$rd"index.html
sed -i "s/m4a)/m4a\')/g" "$rd"index.html

sed -i "s%'20%'./audlyq/20%g" index.html	# 修改播放路径
sed -i '/\"ss\"/d' "$rd"index.html
# sed -i '/@y/d' ./index.html